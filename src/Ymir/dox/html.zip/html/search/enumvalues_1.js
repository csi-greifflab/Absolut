var searchData=
[
  ['backwards_538',['Backwards',['../group___basic_moves.html#gga23a2c5d312564ee531b17f3ecf6450f0af22fce3bb34683109aeea15c2f477156',1,'compact.h']]]
];
