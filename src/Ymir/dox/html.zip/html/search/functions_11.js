var searchData=
[
  ['union_5fsets_465',['union_sets',['../compact_8cpp.html#a4dedf3ad5f6197ebf17e5a74459a7481',1,'union_sets(set&lt; int &gt; &amp;s1, set&lt; int &gt; &amp;s2):&#160;compact.cpp'],['../compact_8h.html#a4dedf3ad5f6197ebf17e5a74459a7481',1,'union_sets(set&lt; int &gt; &amp;s1, set&lt; int &gt; &amp;s2):&#160;compact.cpp']]]
];
