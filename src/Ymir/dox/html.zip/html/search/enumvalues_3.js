var searchData=
[
  ['down_540',['Down',['../group___basic_moves.html#gga23a2c5d312564ee531b17f3ecf6450f0abcf8c79e9a5f5f9d606fb35645a0fb27',1,'compact.h']]]
];
