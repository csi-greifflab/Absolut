var searchData=
[
  ['startingpos1_569',['startingPos1',['../proteins_8cpp.html#a36d52158bcff320a305a3836f4ab0460',1,'proteins.cpp']]],
  ['startingpos2_570',['startingPos2',['../proteins_8cpp.html#a7852031911371a65593b4b4812942024',1,'proteins.cpp']]]
];
