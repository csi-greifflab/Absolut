var searchData=
[
  ['compactstructure_531',['CompactStructure',['../compact_8cpp.html#ab6cbd3548b0b1f9558a26a9e42bbb448',1,'CompactStructure():&#160;compact.cpp'],['../group___struct_manip.html#gab6cbd3548b0b1f9558a26a9e42bbb448',1,'CompactStructure():&#160;compact.h']]]
];
