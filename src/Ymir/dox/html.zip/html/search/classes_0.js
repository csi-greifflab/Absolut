var searchData=
[
  ['affinityoneligand_288',['affinityOneLigand',['../classaffinity_one_ligand.html',1,'']]]
];
