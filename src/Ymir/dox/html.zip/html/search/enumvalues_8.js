var searchData=
[
  ['met_549',['Met',['../group___prot.html#gga098890dde069e9abad63f19a0d9e1f32a9bdeee1cfbcd1f594f931be76105490a',1,'proteins.h']]]
];
