var searchData=
[
  ['ser_554',['Ser',['../group___prot.html#gga098890dde069e9abad63f19a0d9e1f32a8d78650a73f9018a8d49b6e5e18585dd',1,'proteins.h']]],
  ['straight_555',['Straight',['../group___basic_moves.html#gga23a2c5d312564ee531b17f3ecf6450f0ada4cdade2120d083fe09b30940e51c12',1,'compact.h']]]
];
