var searchData=
[
  ['nb_5fmoves_5fabsolute_566',['Nb_Moves_Absolute',['../compact_8h.html#a2d0724ee12e79136b92355774dc0c94d',1,'compact.h']]],
  ['nb_5fmoves_5frelative_567',['Nb_Moves_Relative',['../compact_8h.html#a15eec61288a3d894f007b017c7459e8b',1,'compact.h']]]
];
