var searchData=
[
  ['cys_539',['Cys',['../group___prot.html#gga098890dde069e9abad63f19a0d9e1f32a5384d8ccfa89d9bc44dc36360b92fde8',1,'proteins.h']]]
];
