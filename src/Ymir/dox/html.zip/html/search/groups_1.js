var searchData=
[
  ['compact_20memory_20encoding_20of_20absolute_20and_20relative_20sequences_20into_2064_20bits_20_28compact_2eh_2fcpp_29_2e_573',['Compact memory encoding of absolute and relative sequences into 64 bits (compact.h/cpp).',['../group__compact_encoding.html',1,'']]]
];
