var searchData=
[
  ['encoding_20receptor_2dligand_20interactions_20and_20saving_20enumerated_20receptor_20structures_20into_20files_20_28receptorligand_2eh_2fcpp_29_2e_58',['Encoding receptor-ligand interactions and saving enumerated receptor structures into files (receptorLigand.h/cpp).',['../group___cod_inter.html',1,'']]],
  ['easyrotate_59',['easyRotate',['../group___struct_manip.html#gaef5e8caada4b1a7252ea6f98ff88ed5a',1,'easyRotate(string sequence, moveDirection absAxis, bool clockwise):&#160;compact.cpp'],['../group___struct_manip.html#gaef5e8caada4b1a7252ea6f98ff88ed5a',1,'easyRotate(string seq, moveDirection absAxis, bool clockwise=true):&#160;compact.cpp']]],
  ['end_60',['end',['../group___prot.html#ga4729bf04423977a291c8e8122923a3b1',1,'superProtein']]],
  ['endingposition_61',['endingPosition',['../structstruct3_d.html#a6f440d1bad6611c35c30e9314cb8f8f6',1,'struct3D']]],
  ['ensprots_62',['ensProts',['../structens_prots.html',1,'ensProts'],['../structens_prots.html#a36fabe75c104e04d05f9bdd0a109cecf',1,'ensProts::ensProts()']]],
  ['enumeration_20of_20_28receptor_29_20structures_20around_20a_20predefined_20protein_20_28ligand_3a_20structure_20_2b_20aas_29_20_28receptorligand_2eh_2fcpp_29_63',['Enumeration of (receptor) structures around a predefined protein (ligand: structure + AAs) (receptorligand.h/cpp)',['../group___enum_r_l.html',1,'']]],
  ['errorseq_64',['ERRORSEQ',['../compact_8cpp.html#aada065fb4f4ef8023e0538a7ffcb3710',1,'ERRORSEQ():&#160;compact.cpp'],['../group__compact_encoding.html#gaada065fb4f4ef8023e0538a7ffcb3710',1,'ERRORSEQ():&#160;compact.h']]],
  ['excludecriterion_65',['excludeCriterion',['../proteins_8cpp.html#a4d1eca9a22d7756cfb972f13b56b20c3',1,'proteins.cpp']]],
  ['exportselfinteractions_66',['exportSelfInteractions',['../group___cod_inter.html#gafe5f8dcec1c17404a679d3e358ba7b5c',1,'exportSelfInteractions(vector&lt; struct3D * &gt; &amp;structures, string fname):&#160;receptorligand.cpp'],['../group___cod_inter.html#gafe5f8dcec1c17404a679d3e358ba7b5c',1,'exportSelfInteractions(vector&lt; struct3D * &gt; &amp;structures, string fname):&#160;receptorligand.cpp']]],
  ['encoding_20of_203d_20positions_20in_20a_20_28euclidian_2fcubic_20lattice_29_20into_20an_20integer_20code_20_28lattice_2eh_2fcpp_29_67',['Encoding of 3D positions in a (euclidian/cubic lattice) into an integer code (lattice.h/cpp)',['../group___lattice.html',1,'']]],
  ['encoding_20of_20proteins_20_3d_20structures_20with_20aas_20inside_20_28proteins_2eh_2fcpp_29_68',['Encoding of proteins = Structures with AAs inside (proteins.h/cpp)',['../group___prot.html',1,'']]]
];
