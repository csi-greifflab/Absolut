var searchData=
[
  ['fastaffinity_2ecpp_299',['fastaffinity.cpp',['../fastaffinity_8cpp.html',1,'']]],
  ['fastaffinity_2eh_300',['fastaffinity.h',['../fastaffinity_8h.html',1,'']]]
];
