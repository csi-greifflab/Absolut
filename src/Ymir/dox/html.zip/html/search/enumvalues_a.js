var searchData=
[
  ['phe_551',['Phe',['../group___prot.html#gga098890dde069e9abad63f19a0d9e1f32a4e7d1f561e7a80299d273ce3ebb5f907',1,'proteins.h']]],
  ['pro_552',['Pro',['../group___prot.html#gga098890dde069e9abad63f19a0d9e1f32a8d52dd857d08ca6d6bb37d75074dc85c',1,'proteins.h']]]
];
