var searchData=
[
  ['nb_5faas_550',['NB_AAs',['../group___prot.html#gga098890dde069e9abad63f19a0d9e1f32a8fb64ab971784698c2eb1db30c2acfad',1,'proteins.h']]]
];
