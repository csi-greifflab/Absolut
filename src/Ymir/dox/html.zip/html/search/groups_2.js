var searchData=
[
  ['definitions_20of_20moves_20and_20basic_20functions_20_28compact_2eh_2fcpp_29_2e_574',['Definitions of moves and basic functions (compact.h/cpp).',['../group___basic_moves.html',1,'']]]
];
