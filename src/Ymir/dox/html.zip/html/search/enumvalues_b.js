var searchData=
[
  ['right_553',['Right',['../group___basic_moves.html#gga23a2c5d312564ee531b17f3ecf6450f0ad48f7af8c070184f3774c8e85854eb66',1,'compact.h']]]
];
