var searchData=
[
  ['functions_20to_20manipulate_20structures_20in_20space_20_28compact_2eh_2fcpp_29_2e_579',['Functions to manipulate structures in space (compact.h/cpp).',['../group___struct_manip.html',1,'']]]
];
