var searchData=
[
  ['id_493',['ID',['../group___prot.html#ga99107d4b290b79b9451e7b3db51d741d',1,'superProtein']]],
  ['idposition_494',['IDposition',['../group___prot.html#ga99529b777a085c6a80c0f289d20c55dd',1,'residue']]],
  ['idresidue_495',['IDresidue',['../structresidue.html#a95d98aa2f4af784c815dd23e3a954dea',1,'residue']]],
  ['interactions_496',['interactions',['../classaffinity_one_ligand.html#ab60e7cf268f6e261e3939e7f56f681d0',1,'affinityOneLigand']]]
];
