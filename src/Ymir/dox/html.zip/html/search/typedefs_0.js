var searchData=
[
  ['absolutestructure_530',['AbsoluteStructure',['../compact_8cpp.html#a66e6e2eafcaae9d42d79f9e040cd3618',1,'AbsoluteStructure():&#160;compact.cpp'],['../group___struct_manip.html#ga66e6e2eafcaae9d42d79f9e040cd3618',1,'AbsoluteStructure():&#160;compact.h']]]
];
