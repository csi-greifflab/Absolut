var searchData=
[
  ['gridstartposition_492',['gridStartPosition',['../struct_space_structure.html#a4cffac18453dc1fcc2063a1f7e45b669',1,'SpaceStructure']]]
];
