var searchData=
[
  ['nbprots_511',['nbProts',['../proteins_8cpp.html#a8a2d515304050a38ebb08980ad9a9ba1',1,'proteins.cpp']]],
  ['nbrepeats_512',['nbRepeats',['../classaffinity_one_ligand.html#a9feec0cc13d92d5eb8c0b04f82923884',1,'affinityOneLigand']]],
  ['nbselfrepeats_513',['nbSelfRepeats',['../classaffinity_one_ligand.html#a8171e839a1aa1babf3a352f13c0faa41',1,'affinityOneLigand']]],
  ['nfoldingcodes_514',['nFoldingCodes',['../classaffinity_one_ligand.html#a1777fa1fe36247e36b7134547d8ce35d',1,'affinityOneLigand']]],
  ['nintercodes_515',['nInterCodes',['../classaffinity_one_ligand.html#ac22cbfacc71d28154a615e2ba92746ea',1,'affinityOneLigand']]]
];
