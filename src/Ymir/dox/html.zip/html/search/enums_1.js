var searchData=
[
  ['movedirection_533',['moveDirection',['../group___basic_moves.html#ga23a2c5d312564ee531b17f3ecf6450f0',1,'compact.h']]]
];
