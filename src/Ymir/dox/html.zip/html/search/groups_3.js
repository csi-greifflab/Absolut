var searchData=
[
  ['encoding_20receptor_2dligand_20interactions_20and_20saving_20enumerated_20receptor_20structures_20into_20files_20_28receptorligand_2eh_2fcpp_29_2e_575',['Encoding receptor-ligand interactions and saving enumerated receptor structures into files (receptorLigand.h/cpp).',['../group___cod_inter.html',1,'']]],
  ['enumeration_20of_20_28receptor_29_20structures_20around_20a_20predefined_20protein_20_28ligand_3a_20structure_20_2b_20aas_29_20_28receptorligand_2eh_2fcpp_29_576',['Enumeration of (receptor) structures around a predefined protein (ligand: structure + AAs) (receptorligand.h/cpp)',['../group___enum_r_l.html',1,'']]],
  ['encoding_20of_203d_20positions_20in_20a_20_28euclidian_2fcubic_20lattice_29_20into_20an_20integer_20code_20_28lattice_2eh_2fcpp_29_577',['Encoding of 3D positions in a (euclidian/cubic lattice) into an integer code (lattice.h/cpp)',['../group___lattice.html',1,'']]],
  ['encoding_20of_20proteins_20_3d_20structures_20with_20aas_20inside_20_28proteins_2eh_2fcpp_29_578',['Encoding of proteins = Structures with AAs inside (proteins.h/cpp)',['../group___prot.html',1,'']]]
];
